sap.ui.define([
	"dev/test_prod/test/unit/controller/View1.controller"
], function () {
	"use strict";
});